package com.example.sakibcse.chatserver;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import yuku.ambilwarna.AmbilWarnaDialog;

public class Chat extends AppCompatActivity implements View.OnClickListener {

    private Handler handler = new Handler();
    private boolean end=false;
    EditText writeMessage;
    ImageButton sendBtn;
    ListView messageList;
    MessageAdapter messageAdapter=new MessageAdapter(this);
    private ServerSocket serverSocket;
    private Socket tempClientSocket;
    Thread serverThread = null;
    public static final int SERVER_PORT = 3003;
    public int initialColor,bgColor;
    public String hexColor;
    private LinearLayout chatbg;
    private String filePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        setTitle("Server");

        Toolbar toolbar = findViewById(R.id.toolbarID);
        setSupportActionBar(toolbar);

        loadData();

        chatbg = (LinearLayout) findViewById(R.id.ChatBg);
        chatbg.setBackgroundColor(bgColor);

        writeMessage=(EditText) findViewById(R.id.inputMessage);
        sendBtn=(ImageButton) findViewById(R.id.sendButton);
        messageList=(ListView) findViewById(R.id.messages_view);

        writeMessage.setOnClickListener(this);
        sendBtn.setOnClickListener(this);

        messageList.setAdapter(messageAdapter);
        handler = new Handler();

        this.serverThread = new Thread(new ServerThread());
        this.serverThread.start();

    }

    public void showMessage(final String message, final boolean sender) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                messageAdapter.add(new Message(message,sender));
                if(messageAdapter!=null) messageAdapter.notifyDataSetChanged();
            }
        });
    }

    //change Background

    public void changeBackground(final int color) {
        handler.post(new Runnable() {
            @Override
            public void run() {

                chatbg.setBackgroundColor(color);
                bgColor = color;
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_layout,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()==R.id.saveMenuItem){
            Toast.makeText(getApplicationContext(),"Message saved",Toast.LENGTH_LONG).show();
            saveMessage();
            return true;
        }

        if(item.getItemId()==R.id.background){
            openColorPickerDialogue();
            return true;
        }

        if(item.getItemId()==R.id.fileShare){
            openFileMenu();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void openColorPickerDialogue(){
        AmbilWarnaDialog dialog = new AmbilWarnaDialog(this,initialColor, new AmbilWarnaDialog.OnAmbilWarnaListener() {
            @Override
            public void onCancel(AmbilWarnaDialog dialog) {

            }

            @Override
            public void onOk(AmbilWarnaDialog dialog, int color) {
                initialColor=color;
                bgColor = color;
                chatbg.setBackgroundColor(color);
                hexColor = String.format("#%06X", (0xFFFFFF & color));
                sendMessage(hexColor);
                Toast.makeText(getApplicationContext(),hexColor,Toast.LENGTH_LONG).show();
            }
        });
        dialog.show();
    }

    private void openFileMenu(){
        Intent fileIntent = new Intent(Intent.ACTION_GET_CONTENT);
        fileIntent.setType("*/*");
        startActivityForResult(fileIntent,5);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        switch (requestCode){
            case 5:
                if(resultCode == RESULT_OK){
                   filePath=data.getData().getPath();
                    Uri uri = Uri.parse(filePath);
//                    getTextFromUri(uri);
//                    Toast.makeText(this,filePath,Toast.LENGTH_LONG).show();

                    BufferedReader reader = null;
                    StringBuilder builder = new StringBuilder();
                    try {
                        reader = new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(uri)));
                        String line = "";

                        while ((line = reader.readLine()) != null) {
                            builder.append("\n"+line);
                        }

                    } catch (IOException e) {
                        e.printStackTrace();
                    } finally {
                        if (reader != null){
                            try {
                                reader.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                    //Toast.makeText(this,builder.toString(),Toast.LENGTH_LONG).show();
                    //showMessage(builder.toString(),true);
                }

                break;
        }

    }

    //File Sharing

    public void getTextFromUri(Uri uri){
        BufferedReader reader = null;
        StringBuilder builder = new StringBuilder();
        try {
            reader = new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(uri)));
            String line = "";

            while ((line = reader.readLine()) != null) {
                builder.append("\n"+line);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null){
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }
// Save Message
    private void saveMessage(){
        SharedPreferences sharedPreferences=getSharedPreferences("messageStorageSP",MODE_PRIVATE);
        SharedPreferences.Editor editor= sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(messageAdapter.messages);
        editor.putString("messageList",json);
        editor.putInt("backgroundColor",bgColor);
        editor.apply();
    }
// Load Message from saved Storage
    private void loadData(){
        SharedPreferences sharedPreferences=getSharedPreferences("messageStorageSP",MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("messageList",null);
        Type type = new TypeToken<ArrayList<Message>>() {}.getType();
        messageAdapter.messages = gson.fromJson(json,type);
        bgColor = sharedPreferences.getInt("backgroundColor",bgColor);

        if(messageAdapter.messages == null) {
            messageAdapter.messages = new ArrayList<Message>();
        }

    }
//Send Message When ckick mon send Button
    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.sendButton){
            String messageOUT=writeMessage.getText().toString().trim();

            if(messageOUT!=null && !TextUtils.isEmpty(messageOUT)){
                showMessage(messageOUT,true);
               // Toast.makeText(getApplicationContext(),ip,Toast.LENGTH_LONG).show();
                writeMessage.setText("");
                if (null != serverThread) {
                    sendMessage(messageOUT);
                }
            }
        }
    }


//method for sending message
    private void sendMessage(final String message) {
        try {
            if (null != tempClientSocket) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        PrintWriter out = null;
                        try {
                            out = new PrintWriter(new BufferedWriter(
                                    new OutputStreamWriter(tempClientSocket.getOutputStream())),
                                    true);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        out.println(message);
                    }
                }).start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    class ServerThread implements Runnable {

        public void run() {
            Socket socket;
            try {
                serverSocket = new ServerSocket(SERVER_PORT);
                //findViewById(R.id.start_server).setVisibility(View.GONE);
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(getApplicationContext(),"Error Connecting to Client",Toast.LENGTH_LONG).show();
            }
            if (null != serverSocket) {
                while (!Thread.currentThread().isInterrupted()) {
                    try {
                        socket = serverSocket.accept();
                        CommunicationThread commThread = new CommunicationThread(socket);
                        new Thread(commThread).start();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Toast.makeText(getApplicationContext(),"Error Connecting to Client",Toast.LENGTH_LONG).show();
                    }
                }
            }
        }
    }

    class CommunicationThread implements Runnable {

        private Socket clientSocket;

        private BufferedReader input;

        public CommunicationThread(Socket clientSocket) {
            this.clientSocket = clientSocket;
            tempClientSocket = clientSocket;
            try {
                this.input = new BufferedReader(new InputStreamReader(this.clientSocket.getInputStream()));
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(getApplicationContext(),"Error Connecting to client",Toast.LENGTH_LONG).show();
            }
            Toast.makeText(getApplicationContext(),"Connected to client",Toast.LENGTH_LONG).show();
        }

        public void run() {

            while (!Thread.currentThread().isInterrupted()) {
                try {
                    String read = input.readLine();
                    if (null == read || "Disconnect".contentEquals(read)) {
                        Thread.interrupted();
                        read = "Client Disconnected";
                        Toast.makeText(getApplicationContext(),read,Toast.LENGTH_LONG).show();
                        break;
                    }

                    if(read.charAt(0) == '#') {
                        bgColor = Color.parseColor(read);
                        changeBackground(bgColor);
                    }
                    else if(read.charAt(0)!= '#')
                        showMessage(read,false);

                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }

    }

}


